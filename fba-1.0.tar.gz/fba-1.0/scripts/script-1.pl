#!/usr/bin/perl

print "Hello from script 1\n";