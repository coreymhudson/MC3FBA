#!/usr/bin/perl

print "Hello from script 2\n";